# Lab 02 - Backend Clean Architecture

Project minh hoa cho Lab 02 cua mon Phat trien ung dung Web nang cao.

## Cau truc
- `src/CulinaryBlog.Domain`: entities/domain models.
- `src/CulinaryBlog.Application`: interfaces/use-case contracts.
- `src/CulinaryBlog.Infrastructure`: EF Core DbContext, configurations, migration/seeding, repositories.
- `src/CulinaryBlog.Api`: Web API entry point, Swagger, controller.

## Yeu cau moi truong
- .NET 8 SDK
- PostgreSQL 14+

## Cai package va tao migration
```bash
dotnet restore
dotnet tool install --global dotnet-ef --version 8.0.10
dotnet ef migrations add InitialCreate --project src/CulinaryBlog.Infrastructure --startup-project src/CulinaryBlog.Api --output-dir Migrations
dotnet ef database update --project src/CulinaryBlog.Infrastructure --startup-project src/CulinaryBlog.Api
```

## Chay
```bash
dotnet run --project src/CulinaryBlog.Api
```
Khi API khoi dong, migration duoc ap dung va seed tu dong neu database chua du du lieu.

Kiem tra:
`GET /api/v1/lab/seed-summary`

Muc tieu seed: 20 categories, 100 recipes, 1,000 ingredients (10/recipe), 500 steps (5/recipe).

## Git history goi y
```bash
git add .
git commit -m "Lab02: tao cau truc Clean Architecture"
git add .
git commit -m "Lab02: them EF Core PostgreSQL va DbContext"
git add .
git commit -m "Lab02: them entities va configurations"
git add .
git commit -m "Lab02: them migration va data seeder"
git add .
git commit -m "Lab02: hoan thien seed 20 categories 100 recipes"
git push
```
Chi ghi commit sau khi ban thuc su chay va kiem tra buoc do tren may cua minh.
