using CulinaryBlog.Application.Interfaces;
using Microsoft.AspNetCore.Mvc;
namespace CulinaryBlog.Api.Controllers;
[ApiController]
[Route("api/v1/lab")]
public class LabController(IRecipeQueryService service) : ControllerBase
{
    [HttpGet("seed-summary")]
    public async Task<IActionResult> SeedSummary(CancellationToken cancellationToken) => Ok(await service.GetSummaryAsync(cancellationToken));
}
