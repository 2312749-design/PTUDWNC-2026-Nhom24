namespace CulinaryBlog.Application.Interfaces;
public interface IRecipeSeeder
{
    Task SeedAsync(CancellationToken cancellationToken = default);
}
