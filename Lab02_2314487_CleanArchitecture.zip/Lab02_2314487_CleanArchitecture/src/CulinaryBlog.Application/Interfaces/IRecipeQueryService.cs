namespace CulinaryBlog.Application.Interfaces;
public interface IRecipeQueryService
{
    Task<object> GetSummaryAsync(CancellationToken cancellationToken = default);
}
