using CulinaryBlog.Domain.Entities;
using CulinaryBlog.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.Storage.ValueConversion;

#nullable disable
namespace CulinaryBlog.Infrastructure.Migrations;
[DbContext(typeof(RecipeDbContext))]
partial class RecipeDbContextModelSnapshot : ModelSnapshot
{
    protected override void BuildModel(ModelBuilder modelBuilder)
    {
        modelBuilder.HasAnnotation("ProductVersion", "8.0.10");
        modelBuilder.Entity<Category>(b => { b.ToTable("categories"); b.HasKey(x=>x.Id); b.Property(x=>x.Name).HasMaxLength(100).IsRequired(); b.Property(x=>x.Slug).HasMaxLength(120).IsRequired(); b.HasIndex(x=>x.Slug).IsUnique(); });
        modelBuilder.Entity<Recipe>(b => { b.ToTable("recipes"); b.HasKey(x=>x.Id); b.Property(x=>x.Title).HasMaxLength(200).IsRequired(); b.Property(x=>x.Slug).HasMaxLength(220).IsRequired(); b.Property(x=>x.Description).HasMaxLength(2000).IsRequired(); b.Property(x=>x.Difficulty).HasMaxLength(30).IsRequired(); b.HasIndex(x=>x.Slug).IsUnique(); b.HasOne(x=>x.Category).WithMany(x=>x.Recipes).HasForeignKey(x=>x.CategoryId).OnDelete(DeleteBehavior.Restrict); });
        modelBuilder.Entity<RecipeIngredient>(b => { b.ToTable("recipe_ingredients"); b.HasKey(x=>x.Id); b.Property(x=>x.Name).HasMaxLength(100).IsRequired(); b.Property(x=>x.Quantity).HasPrecision(10,2); b.Property(x=>x.Unit).HasMaxLength(30).IsRequired(); b.Property(x=>x.QuantityDisplay).HasMaxLength(60).IsRequired(); b.HasIndex(x=>new {x.RecipeId,x.OrderIndex}).IsUnique(); b.HasOne(x=>x.Recipe).WithMany(x=>x.Ingredients).HasForeignKey(x=>x.RecipeId).OnDelete(DeleteBehavior.Cascade); });
        modelBuilder.Entity<RecipeStep>(b => { b.ToTable("recipe_steps"); b.HasKey(x=>x.Id); b.Property(x=>x.Title).HasMaxLength(150).IsRequired(); b.Property(x=>x.Description).HasMaxLength(2000).IsRequired(); b.HasIndex(x=>new {x.RecipeId,x.OrderIndex}).IsUnique(); b.HasOne(x=>x.Recipe).WithMany(x=>x.Steps).HasForeignKey(x=>x.RecipeId).OnDelete(DeleteBehavior.Cascade); });
    }
}
