using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable
namespace CulinaryBlog.Infrastructure.Migrations;
public partial class InitialCreate : Migration
{
    protected override void Up(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.CreateTable(name: "categories", columns: table => new
        {
            Id = table.Column<Guid>(type: "uuid", nullable: false),
            Name = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false),
            Slug = table.Column<string>(type: "character varying(120)", maxLength: 120, nullable: false)
        }, constraints: table => table.PrimaryKey("PK_categories", x => x.Id));

        migrationBuilder.CreateTable(name: "recipes", columns: table => new
        {
            Id = table.Column<Guid>(type: "uuid", nullable: false),
            CategoryId = table.Column<Guid>(type: "uuid", nullable: false),
            Title = table.Column<string>(type: "character varying(200)", maxLength: 200, nullable: false),
            Slug = table.Column<string>(type: "character varying(220)", maxLength: 220, nullable: false),
            Description = table.Column<string>(type: "character varying(2000)", maxLength: 2000, nullable: false),
            PrepTimeMinutes = table.Column<int>(type: "integer", nullable: false),
            CookTimeMinutes = table.Column<int>(type: "integer", nullable: false),
            Servings = table.Column<int>(type: "integer", nullable: false),
            Difficulty = table.Column<string>(type: "character varying(30)", maxLength: 30, nullable: false)
        }, constraints: table =>
        {
            table.PrimaryKey("PK_recipes", x => x.Id);
            table.ForeignKey("FK_recipes_categories_CategoryId", x => x.CategoryId, "categories", "Id", onDelete: ReferentialAction.Restrict);
        });

        migrationBuilder.CreateTable(name: "recipe_ingredients", columns: table => new
        {
            Id = table.Column<Guid>(type: "uuid", nullable: false), RecipeId = table.Column<Guid>(type: "uuid", nullable: false),
            Name = table.Column<string>(type: "character varying(100)", maxLength: 100, nullable: false), Quantity = table.Column<decimal>(type: "numeric(10,2)", precision: 10, scale: 2, nullable: false),
            Unit = table.Column<string>(type: "character varying(30)", maxLength: 30, nullable: false), QuantityDisplay = table.Column<string>(type: "character varying(60)", maxLength: 60, nullable: false), OrderIndex = table.Column<int>(type: "integer", nullable: false)
        }, constraints: table =>
        {
            table.PrimaryKey("PK_recipe_ingredients", x => x.Id);
            table.ForeignKey("FK_recipe_ingredients_recipes_RecipeId", x => x.RecipeId, "recipes", "Id", onDelete: ReferentialAction.Cascade);
        });

        migrationBuilder.CreateTable(name: "recipe_steps", columns: table => new
        {
            Id = table.Column<Guid>(type: "uuid", nullable: false), RecipeId = table.Column<Guid>(type: "uuid", nullable: false), OrderIndex = table.Column<int>(type: "integer", nullable: false),
            Title = table.Column<string>(type: "character varying(150)", maxLength: 150, nullable: false), Description = table.Column<string>(type: "character varying(2000)", maxLength: 2000, nullable: false), TimerMinutes = table.Column<int>(type: "integer", nullable: false)
        }, constraints: table =>
        {
            table.PrimaryKey("PK_recipe_steps", x => x.Id);
            table.ForeignKey("FK_recipe_steps_recipes_RecipeId", x => x.RecipeId, "recipes", "Id", onDelete: ReferentialAction.Cascade);
        });

        migrationBuilder.CreateIndex(name: "IX_categories_Slug", table: "categories", column: "Slug", unique: true);
        migrationBuilder.CreateIndex(name: "IX_recipes_CategoryId", table: "recipes", column: "CategoryId");
        migrationBuilder.CreateIndex(name: "IX_recipes_Slug", table: "recipes", column: "Slug", unique: true);
        migrationBuilder.CreateIndex(name: "IX_recipe_ingredients_RecipeId_OrderIndex", table: "recipe_ingredients", columns: new[] { "RecipeId", "OrderIndex" }, unique: true);
        migrationBuilder.CreateIndex(name: "IX_recipe_steps_RecipeId_OrderIndex", table: "recipe_steps", columns: new[] { "RecipeId", "OrderIndex" }, unique: true);
    }
    protected override void Down(MigrationBuilder migrationBuilder)
    {
        migrationBuilder.DropTable(name: "recipe_ingredients");
        migrationBuilder.DropTable(name: "recipe_steps");
        migrationBuilder.DropTable(name: "recipes");
        migrationBuilder.DropTable(name: "categories");
    }
}
