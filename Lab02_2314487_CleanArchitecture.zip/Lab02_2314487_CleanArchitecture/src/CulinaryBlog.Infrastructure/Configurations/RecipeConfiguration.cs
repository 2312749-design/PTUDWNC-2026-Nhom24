using CulinaryBlog.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
namespace CulinaryBlog.Infrastructure.Configurations;
public class RecipeConfiguration : IEntityTypeConfiguration<Recipe>
{
    public void Configure(EntityTypeBuilder<Recipe> b)
    {
        b.ToTable("recipes"); b.HasKey(x=>x.Id);
        b.Property(x=>x.Title).HasMaxLength(200).IsRequired(); b.Property(x=>x.Slug).HasMaxLength(220).IsRequired();
        b.Property(x=>x.Description).HasMaxLength(2000).IsRequired(); b.Property(x=>x.Difficulty).HasMaxLength(30).IsRequired();
        b.HasIndex(x=>x.Slug).IsUnique();
        b.HasOne(x=>x.Category).WithMany(x=>x.Recipes).HasForeignKey(x=>x.CategoryId).OnDelete(DeleteBehavior.Restrict);
    }
}
