using CulinaryBlog.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
namespace CulinaryBlog.Infrastructure.Configurations;
public class RecipeIngredientConfiguration : IEntityTypeConfiguration<RecipeIngredient>
{
    public void Configure(EntityTypeBuilder<RecipeIngredient> b)
    {
        b.ToTable("recipe_ingredients"); b.HasKey(x=>x.Id); b.Property(x=>x.Name).HasMaxLength(100).IsRequired();
        b.Property(x=>x.Quantity).HasPrecision(10,2); b.Property(x=>x.Unit).HasMaxLength(30).IsRequired(); b.Property(x=>x.QuantityDisplay).HasMaxLength(60).IsRequired();
        b.HasOne(x=>x.Recipe).WithMany(x=>x.Ingredients).HasForeignKey(x=>x.RecipeId).OnDelete(DeleteBehavior.Cascade);
        b.HasIndex(x=>new { x.RecipeId, x.OrderIndex }).IsUnique();
    }
}
