using CulinaryBlog.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
namespace CulinaryBlog.Infrastructure.Configurations;
public class CategoryConfiguration : IEntityTypeConfiguration<Category>
{
    public void Configure(EntityTypeBuilder<Category> b)
    {
        b.ToTable("categories"); b.HasKey(x=>x.Id);
        b.Property(x=>x.Name).HasMaxLength(100).IsRequired();
        b.Property(x=>x.Slug).HasMaxLength(120).IsRequired();
        b.HasIndex(x=>x.Slug).IsUnique();
    }
}
