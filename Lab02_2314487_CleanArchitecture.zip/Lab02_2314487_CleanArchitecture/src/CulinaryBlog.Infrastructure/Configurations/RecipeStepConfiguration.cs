using CulinaryBlog.Domain.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
namespace CulinaryBlog.Infrastructure.Configurations;
public class RecipeStepConfiguration : IEntityTypeConfiguration<RecipeStep>
{
    public void Configure(EntityTypeBuilder<RecipeStep> b)
    {
        b.ToTable("recipe_steps"); b.HasKey(x=>x.Id); b.Property(x=>x.Title).HasMaxLength(150).IsRequired(); b.Property(x=>x.Description).HasMaxLength(2000).IsRequired();
        b.HasOne(x=>x.Recipe).WithMany(x=>x.Steps).HasForeignKey(x=>x.RecipeId).OnDelete(DeleteBehavior.Cascade);
        b.HasIndex(x=>new { x.RecipeId, x.OrderIndex }).IsUnique();
    }
}
