using CulinaryBlog.Application.Interfaces;
using CulinaryBlog.Infrastructure.Persistence;
using CulinaryBlog.Infrastructure.Repositories;
using CulinaryBlog.Infrastructure.Seeding;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
namespace CulinaryBlog.Infrastructure;
public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructure(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddDbContext<RecipeDbContext>(o => o.UseNpgsql(configuration.GetConnectionString("DefaultConnection")));
        services.AddScoped<IRecipeSeeder, RecipeSeeder>();
        services.AddScoped<IRecipeQueryService, RecipeQueryService>();
        return services;
    }
}
