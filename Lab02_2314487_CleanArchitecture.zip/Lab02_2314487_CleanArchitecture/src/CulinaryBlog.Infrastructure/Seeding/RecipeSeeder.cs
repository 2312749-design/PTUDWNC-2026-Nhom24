using Bogus;
using CulinaryBlog.Application.Interfaces;
using CulinaryBlog.Domain.Entities;
using CulinaryBlog.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;

namespace CulinaryBlog.Infrastructure.Seeding;
public class RecipeSeeder(RecipeDbContext db) : IRecipeSeeder
{
    private static readonly string[] CategoryNames =
    {
        "Món Việt", "Món Á", "Món Âu", "Món Nhật", "Món Hàn", "Món Thái", "Món Trung Hoa", "Món chay", "Món ăn sáng", "Món chính",
        "Món khai vị", "Món tráng miệng", "Đồ uống", "Bánh ngọt", "Món nướng", "Món chiên", "Món súp", "Salad", "Hải sản", "Món gia đình"
    };

    public async Task SeedAsync(CancellationToken cancellationToken = default)
    {
        if (await db.Categories.CountAsync(cancellationToken) >= 20 && await db.Recipes.CountAsync(cancellationToken) >= 100)
            return;

        var categoryFaker = new Faker<Category>("vi").CustomInstantiator(f => new Category
        {
            Id = Guid.NewGuid(), Name = f.PickRandom(CategoryNames), Slug = f.Random.Word() + "-" + Guid.NewGuid().ToString("N")[..8]
        });
        var categories = new List<Category>();
        for (int i = 0; i < CategoryNames.Length; i++)
            categories.Add(new Category { Id = Guid.NewGuid(), Name = CategoryNames[i], Slug = $"{Slugify(CategoryNames[i])}-{i+1}" });

        var foodFaker = new Faker("vi");
        var units = new[] { "g", "ml", "kg", "thìa", "quả", "củ", "nhánh", "miếng" };
        var difficulties = new[] { "Easy", "Medium", "Hard" };
        var recipes = new List<Recipe>();

        for (int i = 1; i <= 100; i++)
        {
            var title = $"Công thức món ăn {i:000}";
            var recipe = new Recipe
            {
                Id = Guid.NewGuid(), CategoryId = categories[(i - 1) % categories.Count].Id,
                Title = title, Slug = $"cong-thuc-mon-an-{i:000}",
                Description = $"Công thức mẫu {i:000} dùng cho dữ liệu kiểm thử của Lab 02.",
                PrepTimeMinutes = foodFaker.Random.Int(5, 45), CookTimeMinutes = foodFaker.Random.Int(10, 90),
                Servings = foodFaker.Random.Int(1, 6), Difficulty = foodFaker.PickRandom(difficulties)
            };

            for (int j = 1; j <= 10; j++)
            {
                recipe.Ingredients.Add(new RecipeIngredient
                {
                    Id = Guid.NewGuid(), RecipeId = recipe.Id, Name = $"Nguyên liệu {j} cho món {i:000}",
                    Quantity = foodFaker.Random.Decimal(1, 500), Unit = foodFaker.PickRandom(units),
                    QuantityDisplay = $"{foodFaker.Random.Int(1, 5)} {foodFaker.PickRandom(units)}", OrderIndex = j
                });
            }
            for (int s = 1; s <= 5; s++)
            {
                recipe.Steps.Add(new RecipeStep
                {
                    Id = Guid.NewGuid(), RecipeId = recipe.Id, OrderIndex = s,
                    Title = $"Bước {s}", Description = $"Thực hiện công đoạn {s} của món {i:000} theo trình tự.", TimerMinutes = foodFaker.Random.Int(1, 20)
                });
            }
            recipes.Add(recipe);
        }

        db.Categories.AddRange(categories);
        db.Recipes.AddRange(recipes);
        await db.SaveChangesAsync(cancellationToken);
    }

    private static string Slugify(string value) => value.ToLowerInvariant().Replace(' ', '-');
}
