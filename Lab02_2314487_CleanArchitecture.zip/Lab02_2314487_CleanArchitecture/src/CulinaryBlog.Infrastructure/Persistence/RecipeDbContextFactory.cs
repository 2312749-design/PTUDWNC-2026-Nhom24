using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
namespace CulinaryBlog.Infrastructure.Persistence;
public class RecipeDbContextFactory : IDesignTimeDbContextFactory<RecipeDbContext>
{
    public RecipeDbContext CreateDbContext(string[] args)
    {
        var builder = new DbContextOptionsBuilder<RecipeDbContext>();
        builder.UseNpgsql("Host=localhost;Port=5432;Database=culinaryblog_lab02;Username=postgres;Password=postgres");
        return new RecipeDbContext(builder.Options);
    }
}
