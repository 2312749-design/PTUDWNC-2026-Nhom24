using CulinaryBlog.Application.Interfaces;
using CulinaryBlog.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
namespace CulinaryBlog.Infrastructure.Repositories;
public class RecipeQueryService(RecipeDbContext db) : IRecipeQueryService
{
    public async Task<object> GetSummaryAsync(CancellationToken cancellationToken = default)
    {
        var categories = await db.Categories.CountAsync(cancellationToken);
        var recipes = await db.Recipes.CountAsync(cancellationToken);
        var ingredients = await db.RecipeIngredients.CountAsync(cancellationToken);
        var steps = await db.RecipeSteps.CountAsync(cancellationToken);
        return new { categories, recipes, ingredients, steps, minimumIngredientsPerRecipe = recipes == 0 ? 0 : ingredients / recipes, minimumStepsPerRecipe = recipes == 0 ? 0 : steps / recipes };
    }
}
