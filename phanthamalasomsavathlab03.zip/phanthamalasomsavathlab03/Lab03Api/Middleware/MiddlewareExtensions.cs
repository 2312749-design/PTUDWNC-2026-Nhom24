namespace Lab03Api.Middleware;

public static class MiddlewareExtensions
{
    public static IApplicationBuilder UseXuLyLoiToanCuc(this IApplicationBuilder app)
        => app.UseMiddleware<XuLyLoiToanCucMiddleware>();
}
