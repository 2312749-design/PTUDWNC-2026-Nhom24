namespace Lab03Api.Domain.Interfaces;

/// <summary>Repository chung cho moi thuc the.</summary>
public interface IRepository<T> where T : class
{
    Task<T?> LayTheoIdAsync(int id, CancellationToken ct = default);
    Task<List<T>> LayTatCaAsync(CancellationToken ct = default);
    Task ThemAsync(T thucThe, CancellationToken ct = default);
    void CapNhat(T thucThe);
    void Xoa(T thucThe);
}
