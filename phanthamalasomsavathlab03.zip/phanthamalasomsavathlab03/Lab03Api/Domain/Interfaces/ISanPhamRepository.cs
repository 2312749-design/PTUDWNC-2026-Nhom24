using Lab03Api.Domain.Entities;

namespace Lab03Api.Domain.Interfaces;

public interface ISanPhamRepository : IRepository<SanPham>
{
    Task<List<SanPham>> LayTheoDanhMucAsync(int danhMucId, CancellationToken ct = default);
    Task<bool> TonTaiTenAsync(string ten, int? boQuaId = null, CancellationToken ct = default);
}
