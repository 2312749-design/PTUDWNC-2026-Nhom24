namespace Lab03Api.Domain.Interfaces;

/// <summary>
/// Unit of Work: gom cac repository va luu thay doi trong mot giao dich duy nhat.
/// </summary>
public interface IUnitOfWork : IDisposable
{
    IDanhMucRepository DanhMucs { get; }
    ISanPhamRepository SanPhams { get; }

    Task<int> LuuThayDoiAsync(CancellationToken ct = default);
}
