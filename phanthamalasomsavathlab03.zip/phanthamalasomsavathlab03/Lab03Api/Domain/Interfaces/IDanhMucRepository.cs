using Lab03Api.Domain.Entities;

namespace Lab03Api.Domain.Interfaces;

public interface IDanhMucRepository : IRepository<DanhMuc>
{
    Task<bool> TonTaiTenAsync(string ten, int? boQuaId = null, CancellationToken ct = default);
    Task<bool> CoSanPhamAsync(int danhMucId, CancellationToken ct = default);
}
