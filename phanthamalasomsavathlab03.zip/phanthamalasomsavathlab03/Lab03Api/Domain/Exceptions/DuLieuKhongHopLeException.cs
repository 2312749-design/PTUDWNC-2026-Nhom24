namespace Lab03Api.Domain.Exceptions;

/// <summary>Du lieu dau vao vi pham rang buoc cua domain (400).</summary>
public class DuLieuKhongHopLeException : DomainException
{
    public DuLieuKhongHopLeException(string thongDiep)
        : base("DU_LIEU_KHONG_HOP_LE", thongDiep)
    {
    }
}
