namespace Lab03Api.Domain.Exceptions;

/// <summary>
/// Lop co so cho moi loi nghiep vu (domain exception).
/// Middleware se dua vao cac lop con de anh xa sang ma HTTP tuong ung.
/// </summary>
public abstract class DomainException : Exception
{
    public string MaLoi { get; }

    protected DomainException(string maLoi, string thongDiep) : base(thongDiep)
    {
        MaLoi = maLoi;
    }
}
