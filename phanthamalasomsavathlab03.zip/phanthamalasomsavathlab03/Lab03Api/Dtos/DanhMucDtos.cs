using System.ComponentModel.DataAnnotations;

namespace Lab03Api.Dtos;

public record DanhMucRequest(
    [property: Required, StringLength(100)] string Ten,
    [property: StringLength(500)] string? MoTa);

public record DanhMucResponse(int Id, string Ten, string? MoTa);
