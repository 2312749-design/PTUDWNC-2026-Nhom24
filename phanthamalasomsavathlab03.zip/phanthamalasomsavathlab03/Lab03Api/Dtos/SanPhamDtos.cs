using System.ComponentModel.DataAnnotations;

namespace Lab03Api.Dtos;

public record SanPhamRequest(
    [property: Required, StringLength(200)] string Ten,
    decimal Gia,
    int SoLuongTon,
    int DanhMucId);

public record SanPhamResponse(int Id, string Ten, decimal Gia, int SoLuongTon, int DanhMucId);
