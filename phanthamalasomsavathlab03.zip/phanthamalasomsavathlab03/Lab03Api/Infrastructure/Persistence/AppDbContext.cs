using Lab03Api.Domain.Entities;
using Microsoft.EntityFrameworkCore;

namespace Lab03Api.Infrastructure.Persistence;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    public DbSet<DanhMuc> DanhMucs => Set<DanhMuc>();
    public DbSet<SanPham> SanPhams => Set<SanPham>();

    protected override void OnModelCreating(ModelBuilder mb)
    {
        mb.Entity<DanhMuc>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Ten).IsRequired().HasMaxLength(100);
            e.Property(x => x.MoTa).HasMaxLength(500);
            e.HasMany(x => x.SanPhams)
             .WithOne(x => x.DanhMuc)
             .HasForeignKey(x => x.DanhMucId)
             .OnDelete(DeleteBehavior.Restrict);
        });

        mb.Entity<SanPham>(e =>
        {
            e.HasKey(x => x.Id);
            e.Property(x => x.Ten).IsRequired().HasMaxLength(200);
            e.Property(x => x.Gia).HasPrecision(18, 2);
        });
    }
}
