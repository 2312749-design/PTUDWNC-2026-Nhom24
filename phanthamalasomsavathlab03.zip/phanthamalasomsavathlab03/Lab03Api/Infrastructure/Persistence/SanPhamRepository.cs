using Lab03Api.Domain.Entities;
using Lab03Api.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Lab03Api.Infrastructure.Persistence;

public class SanPhamRepository : Repository<SanPham>, ISanPhamRepository
{
    public SanPhamRepository(AppDbContext db) : base(db) { }

    public Task<List<SanPham>> LayTheoDanhMucAsync(int danhMucId, CancellationToken ct = default)
        => _set.AsNoTracking().Where(x => x.DanhMucId == danhMucId).ToListAsync(ct);

    public Task<bool> TonTaiTenAsync(string ten, int? boQuaId = null, CancellationToken ct = default)
    {
        var tenChuan = ten.Trim().ToLower();
        return _set.AnyAsync(x => x.Ten.ToLower() == tenChuan && (boQuaId == null || x.Id != boQuaId), ct);
    }
}
