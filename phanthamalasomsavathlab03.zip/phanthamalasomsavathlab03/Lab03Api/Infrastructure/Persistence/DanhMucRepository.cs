using Lab03Api.Domain.Entities;
using Lab03Api.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Lab03Api.Infrastructure.Persistence;

public class DanhMucRepository : Repository<DanhMuc>, IDanhMucRepository
{
    public DanhMucRepository(AppDbContext db) : base(db) { }

    public Task<bool> TonTaiTenAsync(string ten, int? boQuaId = null, CancellationToken ct = default)
    {
        var tenChuan = ten.Trim().ToLower();
        return _set.AnyAsync(x => x.Ten.ToLower() == tenChuan && (boQuaId == null || x.Id != boQuaId), ct);
    }

    public Task<bool> CoSanPhamAsync(int danhMucId, CancellationToken ct = default)
        => _db.SanPhams.AnyAsync(x => x.DanhMucId == danhMucId, ct);
}
