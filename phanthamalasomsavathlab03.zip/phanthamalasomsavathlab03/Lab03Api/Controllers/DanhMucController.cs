using Lab03Api.Domain.Entities;
using Lab03Api.Domain.Exceptions;
using Lab03Api.Domain.Interfaces;
using Lab03Api.Dtos;
using Microsoft.AspNetCore.Mvc;

namespace Lab03Api.Controllers;

[ApiController]
[Route("api/danh-muc")]
public class DanhMucController : ControllerBase
{
    private readonly IUnitOfWork _uow;

    public DanhMucController(IUnitOfWork uow)
    {
        _uow = uow;
    }

    // GET api/danh-muc
    [HttpGet]
    public async Task<ActionResult<IEnumerable<DanhMucResponse>>> LayDanhSach(CancellationToken ct)
    {
        var ds = await _uow.DanhMucs.LayTatCaAsync(ct);
        return Ok(ds.Select(x => new DanhMucResponse(x.Id, x.Ten, x.MoTa)));
    }

    // GET api/danh-muc/{id}
    [HttpGet("{id:int}")]
    public async Task<ActionResult<DanhMucResponse>> LayTheoId(int id, CancellationToken ct)
    {
        var dm = await _uow.DanhMucs.LayTheoIdAsync(id, ct)
                 ?? throw new KhongTimThayException(nameof(DanhMuc), id);
        return Ok(new DanhMucResponse(dm.Id, dm.Ten, dm.MoTa));
    }

    // POST api/danh-muc
    [HttpPost]
    public async Task<ActionResult<DanhMucResponse>> Tao(DanhMucRequest req, CancellationToken ct)
    {
        if (await _uow.DanhMucs.TonTaiTenAsync(req.Ten, null, ct))
            throw new TrungLapException("Danh muc", req.Ten);

        var dm = new DanhMuc(req.Ten, req.MoTa);
        await _uow.DanhMucs.ThemAsync(dm, ct);
        await _uow.LuuThayDoiAsync(ct);

        return CreatedAtAction(nameof(LayTheoId), new { id = dm.Id },
            new DanhMucResponse(dm.Id, dm.Ten, dm.MoTa));
    }

    // DELETE api/danh-muc/{id}
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Xoa(int id, CancellationToken ct)
    {
        var dm = await _uow.DanhMucs.LayTheoIdAsync(id, ct)
                 ?? throw new KhongTimThayException(nameof(DanhMuc), id);

        if (await _uow.DanhMucs.CoSanPhamAsync(id, ct))
            throw new QuyTacNghiepVuException("Khong the xoa danh muc dang con san pham.");

        _uow.DanhMucs.Xoa(dm);
        await _uow.LuuThayDoiAsync(ct);
        return NoContent();
    }
}
