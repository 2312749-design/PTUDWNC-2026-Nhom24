using Lab03Api.Domain.Entities;
using Lab03Api.Domain.Exceptions;
using Lab03Api.Domain.Interfaces;
using Lab03Api.Dtos;
using Microsoft.AspNetCore.Mvc;

namespace Lab03Api.Controllers;

[ApiController]
[Route("api/san-pham")]
public class SanPhamController : ControllerBase
{
    private readonly IUnitOfWork _uow;

    public SanPhamController(IUnitOfWork uow)
    {
        _uow = uow;
    }

    private static SanPhamResponse ChuyenDoi(SanPham x)
        => new(x.Id, x.Ten, x.Gia, x.SoLuongTon, x.DanhMucId);

    // GET api/san-pham
    [HttpGet]
    public async Task<ActionResult<IEnumerable<SanPhamResponse>>> LayDanhSach(CancellationToken ct)
    {
        var ds = await _uow.SanPhams.LayTatCaAsync(ct);
        return Ok(ds.Select(ChuyenDoi));
    }

    // GET api/san-pham/{id}
    [HttpGet("{id:int}")]
    public async Task<ActionResult<SanPhamResponse>> LayTheoId(int id, CancellationToken ct)
    {
        var sp = await _uow.SanPhams.LayTheoIdAsync(id, ct)
                 ?? throw new KhongTimThayException(nameof(SanPham), id);
        return Ok(ChuyenDoi(sp));
    }

    // POST api/san-pham
    [HttpPost]
    public async Task<ActionResult<SanPhamResponse>> Tao(SanPhamRequest req, CancellationToken ct)
    {
        _ = await _uow.DanhMucs.LayTheoIdAsync(req.DanhMucId, ct)
            ?? throw new KhongTimThayException(nameof(DanhMuc), req.DanhMucId);

        if (await _uow.SanPhams.TonTaiTenAsync(req.Ten, null, ct))
            throw new TrungLapException("San pham", req.Ten);

        var sp = new SanPham(req.Ten, req.Gia, req.SoLuongTon, req.DanhMucId);
        await _uow.SanPhams.ThemAsync(sp, ct);
        await _uow.LuuThayDoiAsync(ct);

        return CreatedAtAction(nameof(LayTheoId), new { id = sp.Id }, ChuyenDoi(sp));
    }

    // PUT api/san-pham/{id}
    [HttpPut("{id:int}")]
    public async Task<ActionResult<SanPhamResponse>> CapNhat(int id, SanPhamRequest req, CancellationToken ct)
    {
        var sp = await _uow.SanPhams.LayTheoIdAsync(id, ct)
                 ?? throw new KhongTimThayException(nameof(SanPham), id);

        _ = await _uow.DanhMucs.LayTheoIdAsync(req.DanhMucId, ct)
            ?? throw new KhongTimThayException(nameof(DanhMuc), req.DanhMucId);

        if (await _uow.SanPhams.TonTaiTenAsync(req.Ten, id, ct))
            throw new TrungLapException("San pham", req.Ten);

        sp.CapNhat(req.Ten, req.Gia, req.SoLuongTon, req.DanhMucId);
        _uow.SanPhams.CapNhat(sp);
        await _uow.LuuThayDoiAsync(ct);

        return Ok(ChuyenDoi(sp));
    }

    // DELETE api/san-pham/{id}
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Xoa(int id, CancellationToken ct)
    {
        var sp = await _uow.SanPhams.LayTheoIdAsync(id, ct)
                 ?? throw new KhongTimThayException(nameof(SanPham), id);

        _uow.SanPhams.Xoa(sp);
        await _uow.LuuThayDoiAsync(ct);
        return NoContent();
    }
}
