# Lab 03 - Domain Exceptions, Repository & Unit of Work, Global Exception Middleware

- Sinh vien: Phan Thama Lasomsavath
- Cong nghe: ASP.NET Core Web API (.NET 8), EF Core (InMemory)

## Cach chay
```bash
cd Lab03Api
dotnet restore
dotnet run
```
Mo Swagger tai: `http://localhost:<port>/swagger`

## Bao cao cong viec

| Yeu cau toi thieu | Trang thai | Vi tri |
|---|---|---|
| Cai dat cac lop domain exceptions | Hoan thanh | `Domain/Exceptions/` |
| Cai dat repository & unit of work | Hoan thanh | `Domain/Interfaces/`, `Infrastructure/Persistence/` |
| It nhat 2 API endpoints / thanh vien | Hoan thanh (9 endpoints) | `Controllers/` |
| Middleware bat loi toan cuc, tra ve ProblemDetails | Hoan thanh | `Middleware/XuLyLoiToanCucMiddleware.cs` |

### Domain exceptions
| Exception | HTTP |
|---|---|
| `DuLieuKhongHopLeException` | 400 |
| `KhongTimThayException` | 404 |
| `TrungLapException` | 409 |
| `QuyTacNghiepVuException` | 422 |
| Exception khac | 500 |

### API endpoints
| Method | URL | Mo ta |
|---|---|---|
| GET | `/api/danh-muc` | Lay danh sach danh muc |
| GET | `/api/danh-muc/{id}` | Lay danh muc theo id |
| POST | `/api/danh-muc` | Tao danh muc (409 neu trung ten) |
| DELETE | `/api/danh-muc/{id}` | Xoa danh muc (422 neu con san pham) |
| GET | `/api/san-pham` | Lay danh sach san pham |
| GET | `/api/san-pham/{id}` | Lay san pham theo id |
| POST | `/api/san-pham` | Tao san pham |
| PUT | `/api/san-pham/{id}` | Cap nhat san pham |
| DELETE | `/api/san-pham/{id}` | Xoa san pham |

### Vi du ProblemDetails (GET /api/san-pham/999)
```json
{
  "type": "https://httpstatuses.io/404",
  "title": "Khong tim thay tai nguyen",
  "status": 404,
  "detail": "Khong tim thay SanPham voi khoa '999'.",
  "instance": "/api/san-pham/999",
  "maLoi": "KHONG_TIM_THAY",
  "traceId": "0HN..."
}
```

### Chua hoan thanh
- Chua ket noi CSDL that (hien dung InMemory).
- Chua viet unit test.
