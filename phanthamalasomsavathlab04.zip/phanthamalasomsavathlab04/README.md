# Lab 04 - Hoan thien tat ca API endpoints

- Sinh vien: Phan Thama Lasomsavath
- Cong nghe: ASP.NET Core Web API (.NET 8), EF Core (InMemory)
- Ke thua toan bo Lab 03 (domain exceptions, repository, unit of work, middleware ProblemDetails)

## Cach chay
```bash
cd Lab04Api
dotnet restore
dotnet run
```
Mo Swagger tai: `http://localhost:<port>/swagger`

## Bao cao cong viec

| Yeu cau toi thieu | Trang thai |
|---|---|
| Hoan thanh viec cai dat tat ca API endpoints | Hoan thanh (14 endpoints) |

### Danh sach endpoints

**Danh muc**
| # | Method | URL | Mo ta | Ma loi co the gap |
|---|---|---|---|---|
| 1 | GET | `/api/danh-muc` | Lay danh sach | |
| 2 | GET | `/api/danh-muc/{id}` | Lay theo id | 404 |
| 3 | GET | `/api/danh-muc/{id}/san-pham` | Lay san pham cua danh muc | 404 |
| 4 | POST | `/api/danh-muc` | Tao moi | 400, 409 |
| 5 | PUT | `/api/danh-muc/{id}` | Cap nhat | 400, 404, 409 |
| 6 | DELETE | `/api/danh-muc/{id}` | Xoa | 404, 422 |

**San pham**
| # | Method | URL | Mo ta | Ma loi co the gap |
|---|---|---|---|---|
| 1 | GET | `/api/san-pham` | Tim kiem, loc, phan trang | 400 |
| 2 | GET | `/api/san-pham/{id}` | Lay theo id | 404 |
| 3 | POST | `/api/san-pham` | Tao moi | 400, 404, 409 |
| 4 | PUT | `/api/san-pham/{id}` | Cap nhat | 400, 404, 409 |
| 5 | PATCH | `/api/san-pham/{id}/gia` | Doi gia | 400, 404 |
| 6 | POST | `/api/san-pham/{id}/nhap-kho` | Nhap kho | 400, 404 |
| 7 | POST | `/api/san-pham/{id}/xuat-kho` | Xuat kho | 400, 404, 422 (ton kho khong du) |
| 8 | DELETE | `/api/san-pham/{id}` | Xoa | 404 |

### Tham so cua GET /api/san-pham
`tuKhoa`, `danhMucId`, `giaTu`, `giaDen`, `trang` (mac dinh 1), `kichThuoc` (mac dinh 10, toi da 100).

Vi du: `GET /api/san-pham?tuKhoa=iphone&giaTu=1000000&trang=1&kichThuoc=5`

### Chua hoan thanh
- Chua ket noi CSDL that (hien dung InMemory).
- Chua viet unit test / integration test.
- Chua co xac thuc, phan quyen.
