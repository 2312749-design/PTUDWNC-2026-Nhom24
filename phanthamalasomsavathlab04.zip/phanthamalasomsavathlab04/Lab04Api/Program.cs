using Lab04Api.Domain.Entities;
using Lab04Api.Domain.Interfaces;
using Lab04Api.Infrastructure.Persistence;
using Lab04Api.Middleware;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Co so du lieu in-memory de chay ngay (doi sang SQL Server/SQLite khi can)
builder.Services.AddDbContext<AppDbContext>(o => o.UseInMemoryDatabase("Lab04Db"));
builder.Services.AddScoped<IUnitOfWork, UnitOfWork>();

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Middleware bat loi toan cuc phai dat dau pipeline
app.UseXuLyLoiToanCuc();

app.UseSwagger();
app.UseSwaggerUI();

app.MapControllers();

// Du lieu mau
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<AppDbContext>();
    if (!db.DanhMucs.Any())
    {
        var dm = new DanhMuc("Dien thoai", "Cac loai dien thoai di dong");
        db.DanhMucs.Add(dm);
        db.SaveChanges();
        db.SanPhams.Add(new SanPham("iPhone 15", 22000000m, 10, dm.Id));
        db.SaveChanges();
    }
}

app.Run();
