using Lab04Api.Domain.Entities;
using Lab04Api.Domain.Exceptions;
using Lab04Api.Domain.Interfaces;
using Lab04Api.Dtos;
using Microsoft.AspNetCore.Mvc;

namespace Lab04Api.Controllers;

[ApiController]
[Route("api/danh-muc")]
public class DanhMucController : ControllerBase
{
    private readonly IUnitOfWork _uow;

    public DanhMucController(IUnitOfWork uow)
    {
        _uow = uow;
    }

    // 1. GET api/danh-muc
    [HttpGet]
    public async Task<ActionResult<IEnumerable<DanhMucResponse>>> LayDanhSach(CancellationToken ct)
    {
        var ds = await _uow.DanhMucs.LayTatCaAsync(ct);
        return Ok(ds.Select(x => new DanhMucResponse(x.Id, x.Ten, x.MoTa)));
    }

    // 2. GET api/danh-muc/{id}
    [HttpGet("{id:int}")]
    public async Task<ActionResult<DanhMucResponse>> LayTheoId(int id, CancellationToken ct)
    {
        var dm = await _uow.DanhMucs.LayTheoIdAsync(id, ct)
                 ?? throw new KhongTimThayException(nameof(DanhMuc), id);
        return Ok(new DanhMucResponse(dm.Id, dm.Ten, dm.MoTa));
    }

    // 3. GET api/danh-muc/{id}/san-pham
    [HttpGet("{id:int}/san-pham")]
    public async Task<ActionResult<IEnumerable<SanPhamResponse>>> LaySanPhamCuaDanhMuc(int id, CancellationToken ct)
    {
        _ = await _uow.DanhMucs.LayTheoIdAsync(id, ct)
            ?? throw new KhongTimThayException(nameof(DanhMuc), id);

        var ds = await _uow.SanPhams.LayTheoDanhMucAsync(id, ct);
        return Ok(ds.Select(x => new SanPhamResponse(x.Id, x.Ten, x.Gia, x.SoLuongTon, x.DanhMucId)));
    }

    // 4. POST api/danh-muc
    [HttpPost]
    public async Task<ActionResult<DanhMucResponse>> Tao(DanhMucRequest req, CancellationToken ct)
    {
        if (await _uow.DanhMucs.TonTaiTenAsync(req.Ten, null, ct))
            throw new TrungLapException("Danh muc", req.Ten);

        var dm = new DanhMuc(req.Ten, req.MoTa);
        await _uow.DanhMucs.ThemAsync(dm, ct);
        await _uow.LuuThayDoiAsync(ct);

        return CreatedAtAction(nameof(LayTheoId), new { id = dm.Id },
            new DanhMucResponse(dm.Id, dm.Ten, dm.MoTa));
    }

    // 5. PUT api/danh-muc/{id}
    [HttpPut("{id:int}")]
    public async Task<ActionResult<DanhMucResponse>> CapNhat(int id, DanhMucRequest req, CancellationToken ct)
    {
        var dm = await _uow.DanhMucs.LayTheoIdAsync(id, ct)
                 ?? throw new KhongTimThayException(nameof(DanhMuc), id);

        if (await _uow.DanhMucs.TonTaiTenAsync(req.Ten, id, ct))
            throw new TrungLapException("Danh muc", req.Ten);

        dm.CapNhat(req.Ten, req.MoTa);
        _uow.DanhMucs.CapNhat(dm);
        await _uow.LuuThayDoiAsync(ct);

        return Ok(new DanhMucResponse(dm.Id, dm.Ten, dm.MoTa));
    }

    // 6. DELETE api/danh-muc/{id}
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Xoa(int id, CancellationToken ct)
    {
        var dm = await _uow.DanhMucs.LayTheoIdAsync(id, ct)
                 ?? throw new KhongTimThayException(nameof(DanhMuc), id);

        if (await _uow.DanhMucs.CoSanPhamAsync(id, ct))
            throw new QuyTacNghiepVuException("Khong the xoa danh muc dang con san pham.");

        _uow.DanhMucs.Xoa(dm);
        await _uow.LuuThayDoiAsync(ct);
        return NoContent();
    }
}
