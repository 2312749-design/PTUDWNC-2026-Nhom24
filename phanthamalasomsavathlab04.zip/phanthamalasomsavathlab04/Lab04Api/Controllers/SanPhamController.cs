using Lab04Api.Domain.Entities;
using Lab04Api.Domain.Exceptions;
using Lab04Api.Domain.Interfaces;
using Lab04Api.Dtos;
using Microsoft.AspNetCore.Mvc;

namespace Lab04Api.Controllers;

[ApiController]
[Route("api/san-pham")]
public class SanPhamController : ControllerBase
{
    private readonly IUnitOfWork _uow;

    public SanPhamController(IUnitOfWork uow)
    {
        _uow = uow;
    }

    private static SanPhamResponse ChuyenDoi(SanPham x)
        => new(x.Id, x.Ten, x.Gia, x.SoLuongTon, x.DanhMucId);

    private async Task<SanPham> LaySanPhamHoacLoiAsync(int id, CancellationToken ct)
        => await _uow.SanPhams.LayTheoIdAsync(id, ct)
           ?? throw new KhongTimThayException(nameof(SanPham), id);

    // 1. GET api/san-pham?tuKhoa=&danhMucId=&giaTu=&giaDen=&trang=1&kichThuoc=10
    [HttpGet]
    public async Task<ActionResult<PhanTrangResponse<SanPhamResponse>>> TimKiem(
        [FromQuery] SanPhamTimKiemQuery q, CancellationToken ct)
    {
        if (q.Trang < 1)
            throw new DuLieuKhongHopLeException("Trang phai >= 1.");
        if (q.KichThuoc < 1 || q.KichThuoc > 100)
            throw new DuLieuKhongHopLeException("Kich thuoc trang phai tu 1 den 100.");
        if (q.GiaTu.HasValue && q.GiaDen.HasValue && q.GiaTu > q.GiaDen)
            throw new DuLieuKhongHopLeException("GiaTu khong duoc lon hon GiaDen.");

        var (ds, tong) = await _uow.SanPhams.TimKiemAsync(
            q.TuKhoa, q.DanhMucId, q.GiaTu, q.GiaDen, q.Trang, q.KichThuoc, ct);

        var tongTrang = (int)Math.Ceiling(tong / (double)q.KichThuoc);
        return Ok(new PhanTrangResponse<SanPhamResponse>(
            ds.Select(ChuyenDoi), q.Trang, q.KichThuoc, tong, tongTrang));
    }

    // 2. GET api/san-pham/{id}
    [HttpGet("{id:int}")]
    public async Task<ActionResult<SanPhamResponse>> LayTheoId(int id, CancellationToken ct)
        => Ok(ChuyenDoi(await LaySanPhamHoacLoiAsync(id, ct)));

    // 3. POST api/san-pham
    [HttpPost]
    public async Task<ActionResult<SanPhamResponse>> Tao(SanPhamRequest req, CancellationToken ct)
    {
        _ = await _uow.DanhMucs.LayTheoIdAsync(req.DanhMucId, ct)
            ?? throw new KhongTimThayException(nameof(DanhMuc), req.DanhMucId);

        if (await _uow.SanPhams.TonTaiTenAsync(req.Ten, null, ct))
            throw new TrungLapException("San pham", req.Ten);

        var sp = new SanPham(req.Ten, req.Gia, req.SoLuongTon, req.DanhMucId);
        await _uow.SanPhams.ThemAsync(sp, ct);
        await _uow.LuuThayDoiAsync(ct);

        return CreatedAtAction(nameof(LayTheoId), new { id = sp.Id }, ChuyenDoi(sp));
    }

    // 4. PUT api/san-pham/{id}
    [HttpPut("{id:int}")]
    public async Task<ActionResult<SanPhamResponse>> CapNhat(int id, SanPhamRequest req, CancellationToken ct)
    {
        var sp = await LaySanPhamHoacLoiAsync(id, ct);

        _ = await _uow.DanhMucs.LayTheoIdAsync(req.DanhMucId, ct)
            ?? throw new KhongTimThayException(nameof(DanhMuc), req.DanhMucId);

        if (await _uow.SanPhams.TonTaiTenAsync(req.Ten, id, ct))
            throw new TrungLapException("San pham", req.Ten);

        sp.CapNhat(req.Ten, req.Gia, req.SoLuongTon, req.DanhMucId);
        _uow.SanPhams.CapNhat(sp);
        await _uow.LuuThayDoiAsync(ct);

        return Ok(ChuyenDoi(sp));
    }

    // 5. PATCH api/san-pham/{id}/gia
    [HttpPatch("{id:int}/gia")]
    public async Task<ActionResult<SanPhamResponse>> DoiGia(int id, DoiGiaRequest req, CancellationToken ct)
    {
        var sp = await LaySanPhamHoacLoiAsync(id, ct);
        sp.DoiGia(req.Gia);
        _uow.SanPhams.CapNhat(sp);
        await _uow.LuuThayDoiAsync(ct);
        return Ok(ChuyenDoi(sp));
    }

    // 6. POST api/san-pham/{id}/nhap-kho
    [HttpPost("{id:int}/nhap-kho")]
    public async Task<ActionResult<SanPhamResponse>> NhapKho(int id, SoLuongRequest req, CancellationToken ct)
    {
        var sp = await LaySanPhamHoacLoiAsync(id, ct);
        sp.NhapKho(req.SoLuong);
        _uow.SanPhams.CapNhat(sp);
        await _uow.LuuThayDoiAsync(ct);
        return Ok(ChuyenDoi(sp));
    }

    // 7. POST api/san-pham/{id}/xuat-kho
    [HttpPost("{id:int}/xuat-kho")]
    public async Task<ActionResult<SanPhamResponse>> XuatKho(int id, SoLuongRequest req, CancellationToken ct)
    {
        var sp = await LaySanPhamHoacLoiAsync(id, ct);
        sp.XuatKho(req.SoLuong);
        _uow.SanPhams.CapNhat(sp);
        await _uow.LuuThayDoiAsync(ct);
        return Ok(ChuyenDoi(sp));
    }

    // 8. DELETE api/san-pham/{id}
    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Xoa(int id, CancellationToken ct)
    {
        var sp = await LaySanPhamHoacLoiAsync(id, ct);
        _uow.SanPhams.Xoa(sp);
        await _uow.LuuThayDoiAsync(ct);
        return NoContent();
    }
}
