using Lab04Api.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Lab04Api.Infrastructure.Persistence;

public class Repository<T> : IRepository<T> where T : class
{
    protected readonly AppDbContext _db;
    protected readonly DbSet<T> _set;

    public Repository(AppDbContext db)
    {
        _db = db;
        _set = db.Set<T>();
    }

    public async Task<T?> LayTheoIdAsync(int id, CancellationToken ct = default)
        => await _set.FindAsync(new object[] { id }, ct);

    public async Task<List<T>> LayTatCaAsync(CancellationToken ct = default)
        => await _set.AsNoTracking().ToListAsync(ct);

    public async Task ThemAsync(T thucThe, CancellationToken ct = default)
        => await _set.AddAsync(thucThe, ct);

    public void CapNhat(T thucThe) => _set.Update(thucThe);

    public void Xoa(T thucThe) => _set.Remove(thucThe);
}
