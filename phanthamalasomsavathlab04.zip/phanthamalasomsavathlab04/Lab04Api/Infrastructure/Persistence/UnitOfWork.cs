using Lab04Api.Domain.Interfaces;

namespace Lab04Api.Infrastructure.Persistence;

public class UnitOfWork : IUnitOfWork
{
    private readonly AppDbContext _db;
    private IDanhMucRepository? _danhMucs;
    private ISanPhamRepository? _sanPhams;

    public UnitOfWork(AppDbContext db)
    {
        _db = db;
    }

    public IDanhMucRepository DanhMucs => _danhMucs ??= new DanhMucRepository(_db);
    public ISanPhamRepository SanPhams => _sanPhams ??= new SanPhamRepository(_db);

    public Task<int> LuuThayDoiAsync(CancellationToken ct = default) => _db.SaveChangesAsync(ct);

    public void Dispose() => _db.Dispose();
}
