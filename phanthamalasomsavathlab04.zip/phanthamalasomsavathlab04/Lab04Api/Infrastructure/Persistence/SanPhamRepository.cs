using Lab04Api.Domain.Entities;
using Lab04Api.Domain.Interfaces;
using Microsoft.EntityFrameworkCore;

namespace Lab04Api.Infrastructure.Persistence;

public class SanPhamRepository : Repository<SanPham>, ISanPhamRepository
{
    public SanPhamRepository(AppDbContext db) : base(db) { }

    public Task<List<SanPham>> LayTheoDanhMucAsync(int danhMucId, CancellationToken ct = default)
        => _set.AsNoTracking().Where(x => x.DanhMucId == danhMucId).ToListAsync(ct);

    public Task<bool> TonTaiTenAsync(string ten, int? boQuaId = null, CancellationToken ct = default)
    {
        var tenChuan = ten.Trim().ToLower();
        return _set.AnyAsync(x => x.Ten.ToLower() == tenChuan && (boQuaId == null || x.Id != boQuaId), ct);
    }

    public async Task<(List<SanPham> DanhSach, int Tong)> TimKiemAsync(
        string? tuKhoa, int? danhMucId, decimal? giaTu, decimal? giaDen,
        int trang, int kichThuoc, CancellationToken ct = default)
    {
        var q = _set.AsNoTracking().AsQueryable();

        if (!string.IsNullOrWhiteSpace(tuKhoa))
        {
            var k = tuKhoa.Trim().ToLower();
            q = q.Where(x => x.Ten.ToLower().Contains(k));
        }
        if (danhMucId.HasValue) q = q.Where(x => x.DanhMucId == danhMucId.Value);
        if (giaTu.HasValue) q = q.Where(x => x.Gia >= giaTu.Value);
        if (giaDen.HasValue) q = q.Where(x => x.Gia <= giaDen.Value);

        var tong = await q.CountAsync(ct);
        var ds = await q.OrderBy(x => x.Id)
                        .Skip((trang - 1) * kichThuoc)
                        .Take(kichThuoc)
                        .ToListAsync(ct);
        return (ds, tong);
    }
}
