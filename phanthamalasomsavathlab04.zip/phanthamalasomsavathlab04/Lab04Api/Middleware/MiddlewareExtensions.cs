namespace Lab04Api.Middleware;

public static class MiddlewareExtensions
{
    public static IApplicationBuilder UseXuLyLoiToanCuc(this IApplicationBuilder app)
        => app.UseMiddleware<XuLyLoiToanCucMiddleware>();
}
