using System.Text.Json;
using Lab04Api.Domain.Exceptions;
using Microsoft.AspNetCore.Mvc;

namespace Lab04Api.Middleware;

/// <summary>
/// Middleware bat moi exception chua duoc xu ly va tra ve ProblemDetails (RFC 7807).
/// - DomainException  -> 400 / 404 / 409 / 422 tuy loai
/// - Exception khac   -> 500 (khong lo thong tin noi bo khi chay Production)
/// </summary>
public class XuLyLoiToanCucMiddleware
{
    private static readonly JsonSerializerOptions JsonOptions = new(JsonSerializerDefaults.Web);

    private readonly RequestDelegate _next;
    private readonly ILogger<XuLyLoiToanCucMiddleware> _logger;
    private readonly IHostEnvironment _env;

    public XuLyLoiToanCucMiddleware(
        RequestDelegate next,
        ILogger<XuLyLoiToanCucMiddleware> logger,
        IHostEnvironment env)
    {
        _next = next;
        _logger = logger;
        _env = env;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex) when (!context.Response.HasStarted)
        {
            await XuLyExceptionAsync(context, ex);
        }
    }

    private async Task XuLyExceptionAsync(HttpContext context, Exception ex)
    {
        var (status, tieuDe, maLoi) = ex switch
        {
            KhongTimThayException e => (StatusCodes.Status404NotFound, "Khong tim thay tai nguyen", e.MaLoi),
            DuLieuKhongHopLeException e => (StatusCodes.Status400BadRequest, "Du lieu khong hop le", e.MaLoi),
            TrungLapException e => (StatusCodes.Status409Conflict, "Du lieu bi trung lap", e.MaLoi),
            QuyTacNghiepVuException e => (StatusCodes.Status422UnprocessableEntity, "Vi pham quy tac nghiep vu", e.MaLoi),
            _ => (StatusCodes.Status500InternalServerError, "Loi he thong", "LOI_HE_THONG")
        };

        if (status >= 500)
            _logger.LogError(ex, "Loi khong mong doi tai {Path}", context.Request.Path);
        else
            _logger.LogWarning("Loi nghiep vu [{MaLoi}]: {ThongDiep}", maLoi, ex.Message);

        var problem = new ProblemDetails
        {
            Status = status,
            Title = tieuDe,
            Type = $"https://httpstatuses.io/{status}",
            Detail = status >= 500 && !_env.IsDevelopment()
                ? "Da xay ra loi khong mong doi. Vui long thu lai sau."
                : ex.Message,
            Instance = context.Request.Path
        };
        problem.Extensions["maLoi"] = maLoi;
        problem.Extensions["traceId"] = context.TraceIdentifier;

        context.Response.Clear();
        context.Response.StatusCode = status;
        context.Response.ContentType = "application/problem+json";
        await context.Response.WriteAsync(JsonSerializer.Serialize(problem, JsonOptions));
    }
}
