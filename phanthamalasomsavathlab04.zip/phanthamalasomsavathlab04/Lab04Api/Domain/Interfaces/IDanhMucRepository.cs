using Lab04Api.Domain.Entities;

namespace Lab04Api.Domain.Interfaces;

public interface IDanhMucRepository : IRepository<DanhMuc>
{
    Task<bool> TonTaiTenAsync(string ten, int? boQuaId = null, CancellationToken ct = default);
    Task<bool> CoSanPhamAsync(int danhMucId, CancellationToken ct = default);
}
