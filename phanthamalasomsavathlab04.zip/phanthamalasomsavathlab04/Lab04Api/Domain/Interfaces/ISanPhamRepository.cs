using Lab04Api.Domain.Entities;

namespace Lab04Api.Domain.Interfaces;

public interface ISanPhamRepository : IRepository<SanPham>
{
    Task<List<SanPham>> LayTheoDanhMucAsync(int danhMucId, CancellationToken ct = default);
    Task<bool> TonTaiTenAsync(string ten, int? boQuaId = null, CancellationToken ct = default);

    Task<(List<SanPham> DanhSach, int Tong)> TimKiemAsync(
        string? tuKhoa, int? danhMucId, decimal? giaTu, decimal? giaDen,
        int trang, int kichThuoc, CancellationToken ct = default);
}
