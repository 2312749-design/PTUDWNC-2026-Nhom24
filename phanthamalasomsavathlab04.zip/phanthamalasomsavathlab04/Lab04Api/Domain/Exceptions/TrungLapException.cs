namespace Lab04Api.Domain.Exceptions;

/// <summary>Du lieu bi trung (vi du: trung ten) (409).</summary>
public class TrungLapException : DomainException
{
    public TrungLapException(string tenThucThe, string giaTri)
        : base("TRUNG_LAP", $"{tenThucThe} '{giaTri}' da ton tai.")
    {
    }
}
