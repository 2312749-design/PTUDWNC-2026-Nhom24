namespace Lab04Api.Domain.Exceptions;

/// <summary>Khong tim thay thuc the theo khoa yeu cau (404).</summary>
public class KhongTimThayException : DomainException
{
    public KhongTimThayException(string tenThucThe, object khoa)
        : base("KHONG_TIM_THAY", $"Khong tim thay {tenThucThe} voi khoa '{khoa}'.")
    {
    }
}
