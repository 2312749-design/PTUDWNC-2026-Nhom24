namespace Lab04Api.Domain.Exceptions;

/// <summary>Vi pham quy tac nghiep vu (vi du: xoa danh muc con san pham) (422).</summary>
public class QuyTacNghiepVuException : DomainException
{
    public QuyTacNghiepVuException(string thongDiep)
        : base("VI_PHAM_QUY_TAC_NGHIEP_VU", thongDiep)
    {
    }
}
