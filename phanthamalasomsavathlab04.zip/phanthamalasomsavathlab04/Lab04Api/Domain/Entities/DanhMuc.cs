using Lab04Api.Domain.Exceptions;

namespace Lab04Api.Domain.Entities;

public class DanhMuc
{
    public int Id { get; private set; }
    public string Ten { get; private set; } = string.Empty;
    public string? MoTa { get; private set; }
    public ICollection<SanPham> SanPhams { get; private set; } = new List<SanPham>();

    private DanhMuc() { } // danh cho EF Core

    public DanhMuc(string ten, string? moTa)
    {
        CapNhat(ten, moTa);
    }

    public void CapNhat(string ten, string? moTa)
    {
        if (string.IsNullOrWhiteSpace(ten))
            throw new DuLieuKhongHopLeException("Ten danh muc khong duoc de trong.");
        if (ten.Length > 100)
            throw new DuLieuKhongHopLeException("Ten danh muc toi da 100 ky tu.");

        Ten = ten.Trim();
        MoTa = moTa?.Trim();
    }
}
