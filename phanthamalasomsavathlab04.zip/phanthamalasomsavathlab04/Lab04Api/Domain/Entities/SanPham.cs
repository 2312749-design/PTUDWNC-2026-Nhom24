using Lab04Api.Domain.Exceptions;

namespace Lab04Api.Domain.Entities;

public class SanPham
{
    public int Id { get; private set; }
    public string Ten { get; private set; } = string.Empty;
    public decimal Gia { get; private set; }
    public int SoLuongTon { get; private set; }
    public int DanhMucId { get; private set; }
    public DanhMuc? DanhMuc { get; private set; }

    private SanPham() { } // danh cho EF Core

    public SanPham(string ten, decimal gia, int soLuongTon, int danhMucId)
    {
        CapNhat(ten, gia, soLuongTon, danhMucId);
    }

    public void CapNhat(string ten, decimal gia, int soLuongTon, int danhMucId)
    {
        if (string.IsNullOrWhiteSpace(ten))
            throw new DuLieuKhongHopLeException("Ten san pham khong duoc de trong.");
        if (gia < 0)
            throw new DuLieuKhongHopLeException("Gia san pham khong duoc am.");
        if (soLuongTon < 0)
            throw new DuLieuKhongHopLeException("So luong ton khong duoc am.");

        Ten = ten.Trim();
        Gia = gia;
        SoLuongTon = soLuongTon;
        DanhMucId = danhMucId;
    }

    public void DoiGia(decimal giaMoi)
    {
        if (giaMoi < 0)
            throw new DuLieuKhongHopLeException("Gia san pham khong duoc am.");
        Gia = giaMoi;
    }

    public void NhapKho(int soLuong)
    {
        if (soLuong <= 0)
            throw new DuLieuKhongHopLeException("So luong nhap phai lon hon 0.");
        SoLuongTon += soLuong;
    }

    public void XuatKho(int soLuong)
    {
        if (soLuong <= 0)
            throw new DuLieuKhongHopLeException("So luong xuat phai lon hon 0.");
        if (soLuong > SoLuongTon)
            throw new QuyTacNghiepVuException($"Ton kho khong du. Hien con {SoLuongTon}, yeu cau xuat {soLuong}.");
        SoLuongTon -= soLuong;
    }
}
