using System.ComponentModel.DataAnnotations;

namespace Lab04Api.Dtos;

public record SanPhamRequest(
    [property: Required, StringLength(200)] string Ten,
    decimal Gia,
    int SoLuongTon,
    int DanhMucId);

public record SanPhamResponse(int Id, string Ten, decimal Gia, int SoLuongTon, int DanhMucId);

public record DoiGiaRequest(decimal Gia);

public record SoLuongRequest(int SoLuong);

/// <summary>Tham so tim kiem, loc va phan trang san pham (query string).</summary>
public class SanPhamTimKiemQuery
{
    public string? TuKhoa { get; set; }
    public int? DanhMucId { get; set; }
    public decimal? GiaTu { get; set; }
    public decimal? GiaDen { get; set; }
    public int Trang { get; set; } = 1;
    public int KichThuoc { get; set; } = 10;
}

public record PhanTrangResponse<T>(IEnumerable<T> DuLieu, int Trang, int KichThuoc, int TongSoBanGhi, int TongSoTrang);
